// Constants can be moved here for scalability
export const MOCK_DELAY = 2000;
